# Interface: Reader Agent
Ref: SYSTEM_MAP §8.1

- Input: Fact Packets (+ structured context)
- Output: Proposals (schema-valid)
- No tools. No raw untrusted inputs.
