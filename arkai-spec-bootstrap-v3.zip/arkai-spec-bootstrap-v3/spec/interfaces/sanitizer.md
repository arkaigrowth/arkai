# Interface: Sanitizer
Ref: SYSTEM_MAP §7

- Input: Capsules (untrusted)
- Output: Fact Packets (deterministic)
- No LLM.
