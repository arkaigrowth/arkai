# Interface: Executor
Ref: SYSTEM_MAP §8.3

- Whitelisted deterministic actions only
- Emits events for every side effect
- Never sees raw untrusted inputs
