# Interface: Critic Gate
Ref: SYSTEM_MAP §8.2, §5

- Input: Proposals
- Output: approve|deny|ask_user decisions
- Enforces blast radius caps.
