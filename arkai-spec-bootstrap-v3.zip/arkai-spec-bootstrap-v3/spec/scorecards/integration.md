# Scorecard: Integration
- [ ] Schemas validate (Draft 2020-12)
- [ ] Event envelope aligns with serde JSONL storage
- [ ] Replay parser can reconstruct causal chain
- [ ] Backlog items reference SYSTEM_MAP anchors
