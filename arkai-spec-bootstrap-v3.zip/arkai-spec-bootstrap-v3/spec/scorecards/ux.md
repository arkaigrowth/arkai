# Scorecard: UX (Cockpit)
- [ ] SCAN/CYCLE/ZOOM/ACT/REMEMBER implemented
- [ ] One suggestion at a time
- [ ] Snooze + “don’t ask again”
- [ ] Probabilistic phrasing; no certainty claims
- [ ] No guilt language
