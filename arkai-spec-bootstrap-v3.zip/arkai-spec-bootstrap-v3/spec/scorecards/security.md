# Scorecard: Security
- [ ] Sense/Think/Act separation intact
- [ ] Untrusted quarantined; only fact packets downstream
- [ ] Critic gate required for any side effect
- [ ] Blast radius caps enforced
- [ ] All side effects logged as events (JSONL)
