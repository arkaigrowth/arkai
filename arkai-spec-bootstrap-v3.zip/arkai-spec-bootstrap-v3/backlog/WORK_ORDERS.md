# WORK_ORDERS (Parallelizable)

A) Spine Audit (Flight Recorder reality check)
- Confirm current Event envelope + JSONL schema (serde)
- Decide: payload_summary-only MVP vs payload_ref v2
- Add trace/span/actor/schema_version fields as nullable (PR-1)

B) Spec Kernel Bootstrap
- Add CI schema validation (Draft 2020-12)
- Add schema versioning policy

C) Capsule Capture
D) Sanitizer
E) Critic Gate
F) Mnemo
G) Workout
H) Nudges
I) Replay UI
J) Gmail (gated)
